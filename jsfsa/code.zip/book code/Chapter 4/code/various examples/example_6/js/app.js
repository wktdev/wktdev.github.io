"use strict";

for (let i = 0; i <= 16; i += 1) {
    console.log(i);
}