"use strict";

let synths = ['synth-1', 'synth-2', 'synth-3', 'synth-4'];
console.log(synths.length); //__This is 4
for (let i = 0; i < synths.length; i += 1) {
    console.log(synths[i]);
}