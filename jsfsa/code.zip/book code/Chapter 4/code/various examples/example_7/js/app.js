"use strict";

/*__________________________________BEGIN Helper function.
Ignore this code it is simply being used to pause the for loop */
function sleep(milliseconds) {
    let start = new Date().getTime();
    for (let i = 0; i < 1e7; i++) {
        if ((new Date().getTime() - start) > milliseconds) {
            break;
        }
    }
}
//__________________________________END Helper function
//__________________________________BEGIN Web Audio API setup
let audioContext = new AudioContext();
let osc = audioContext.createOscillator();
osc.type = "sawtooth";
osc.frequency.value = 30;
osc.connect(audioContext.destination);
osc.start(audioContext.currentTime);

//__________________________________END Web Audio API setup
//_________________________________BEGIN audible for-loop example
for (let i = 0; i < 10; i += 1) {
    osc.frequency.value += 100;
    sleep(500);
}
//_________________________________END audible for-loop example