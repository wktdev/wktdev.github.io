"use strict";

//______________________________BEGIN setup

const audioContext = new AudioContext();
let osc = audioContext.createOscillator();
osc.type = "sine";
osc.connect(audioContext.destination);
osc.start(audioContext.currentTime);

//_______________________________END setup
//_______________________________BEGIN Ternary example

osc.type === "sawtooth" ? osc.frequency.value = 50 : osc.frequency.value = 500;

//_______________________________END Ternary example