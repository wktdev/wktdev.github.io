"use strict";


let add = function(a, b) {
    return a + b;
};

add(2, 3); // 5