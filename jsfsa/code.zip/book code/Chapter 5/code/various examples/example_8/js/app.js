"use strict";






function playOsc(oscType, freq) {
    if (arguments.length !== 2) {
        throw "Error! This function takes two arguments ";
    }
}

playOsc("sine"); //___Error! This function takes two arguments