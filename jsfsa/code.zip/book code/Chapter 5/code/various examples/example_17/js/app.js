"use strict";




multFreq(200, 2); // ___ error! "multFreq is not a function"
let multFreq = function(input, val) {
    return input * val;
};