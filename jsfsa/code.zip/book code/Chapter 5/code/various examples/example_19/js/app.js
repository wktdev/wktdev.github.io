"use strict";





(function add(a, b) { //_____ parameters
    return a + b;
}(2, 3)); //___________________arguments