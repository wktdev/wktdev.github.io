"use strict";




let myData; //_______________________________variable declared
myData = "important data goes here"; //__variable initialized
/*The following variable is declared and initialized in one line*/
let playOsc = false;