"use strict";




function effectsBox() {
    let component = "Pulled out component";
    return function openEffectsBox() {
        return component
    }
}
let getComponent = effectsBox(); //___stores "openEffectsBox" function in a variable.
console.log(getComponent()); // "Pulled out component"