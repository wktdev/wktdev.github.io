"use strict";


let add = function(a, b) {
    return a + b;
};

var container = add(2, 3);
console.log(container); // 5