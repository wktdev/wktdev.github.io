"use strict";






function iHaveData() {
    var data = "The data";
}

function iWantData() {
    return data;
}
iWantData(); // data is not defined