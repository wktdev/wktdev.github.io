"use strict";


function effectsBox(input, multiplier) {

    return input * multiplier;
}

console.log(effectsBox(120, 2)); // Output 240