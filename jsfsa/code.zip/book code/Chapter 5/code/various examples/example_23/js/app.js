"use strict";




function effectsBox() {
    let counter = 0;
    let component = "Pulled out component";
    return function openEffectsBox() {
        return component + " " + (counter += 1);
    };
}
let getComponent = effectsBox(); //___stores "openEffectsBox" function in a variable.

getComponent(); // "Pulled out component 1"
getComponent(); // "Pulled out component 2"
getComponent(); // "Pulled out component 3"
getComponent(); // "Pulled out component 4"