"use strict";



  




  

let sound = audioBatchLoader({ 

    snare: "sounds/snare.mp3", 

    kick: "sounds/kick.mp3", 

    hihat: "sounds/hihat.mp3" 

}); 

  





  

window.addEventListener("mousedown", function() { 

    sound.snare.play(); 

}); 
