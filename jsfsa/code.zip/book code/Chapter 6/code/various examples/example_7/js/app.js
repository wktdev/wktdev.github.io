"use strict";



let synth = {
    name: "Moog",
    polyphony: 32
};

let synthWithFilters = Object.create(synth); // clone synth
// synthWithFilters now has access to name and polyphony properties
synthWithFilters.filters = ["lowpass", "highpass", "bandpass"]; // add property
//  The original synth object does not have access to the filters property.
let synthWithFiltersAndEffects = Object.create(synthWithFilters); // clone synthWithFilters
synthWithFiltersAndEffects.effects = ["reverb", "flange", "chorus"]; // add property
// Neither the synth object nor the synthWithFilters object have access to the effects property