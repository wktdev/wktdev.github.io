"use strict";


let blastSound = {
    name: "Blast"
};

function descriptor(message) {
    return this.name + ": " + message;
}

let describeBlastSound = descriptor.bind(blastSound);
console.log(describeBlastSound("This is an explosive sound")); //Blast: This is an explosive sound