"use strict";


let obj = {
    key1: "value1",
    key2: "value2"
};