"use strict";



let song = {
    name: "Funky Shuffle",
    artist: "James Jackson",
    format: "wave",
    sampleRate: 44100,
    nameAndArtist: function() {
        return "Name: " + song.name + " | " + "Artist: " + song.artist
    }

}


for (let prop in song) {
    if (typeof song[prop] !== "function") {
        console.log(song[prop]); //___Omits methods
    };
};