"use strict";

$(function() {

  
    let playing = undefined;
    let left = audioContext.createGain();
    let right = audioContext.createGain();
    let leftVal = 1;
    let rightVal = 1;

   
    let sound = audioBatchLoader({
        drums: "sounds/drums.mp3",


    });





function nodeGraph(sound){

    let splitter = audioContext.createChannelSplitter(2);
    let pannerLeft = audioContext.createStereoPanner();
    let pannerRight = audioContext.createStereoPanner();
    left = audioContext.createGain();
    right = audioContext.createGain();
    sound.loop = true;
    sound.connect(splitter);
    splitter.connect(left, 0); //___connect left channel to gain node
    splitter.connect(right, 1); //__connect right channel to gain node
    left.gain.value = leftVal; //_________independent left channel control
    right.gain.value = rightVal; //________independent right channel control
    left.connect(pannerLeft);
    pannerLeft.pan.value = -1;
    pannerRight.pan.value = 1;
    right.connect(pannerRight);
    pannerLeft.connect(audioContext.destination);
    pannerRight.connect(audioContext.destination);

}


















    $(".transport-icon").on("click", function() {


        if (!playing) {
            playing = true;
            sound.drums.connect(nodeGraph).play();
            $(".transport-icon").attr("src", "images/stop.png");

        } else {
            playing = false;
            sound.drums.stop();
            $(".transport-icon").attr("src", "images/play.png");
        }



    });


    setInterval(function() {

        left.gain.value = leftVal;
        right.gain.value = rightVal;
    }, 50);



    let leftSliderVals = {
        'orientation': "vertical",
        "value": 1,
        'range': "min",
        'min': 0,
        'max': 3,
        'animate': true,
        'step': 0.01,
        'slide': function(event, ui) {

            leftVal = +ui.value;



        }


    };

    $('#left-slider').slider(leftSliderVals);



    let rightSliderVals = {
        'orientation': "vertical",
        "value": 1,
        'range': "min",
        'min': 0,
        'max': 3,
        'animate': true,
        'step': 0.01,
        'slide': function(event, ui) {

            rightVal = +ui.value;



        }


    };

    $('#right-slider').slider(rightSliderVals);
});