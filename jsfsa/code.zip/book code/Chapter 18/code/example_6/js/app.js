"use strict";



function nodeGraph(sound){

        let merger = audioContext.createChannelMerger();
        let splitter = audioContext.createChannelSplitter();
        sound.connect(splitter);
        splitter.connect(merger, 0, 1);
        splitter.connect(merger, 1, 0);
        sound.connect(audioContext.destination); // input right and output left
}


let sound = audioBatchLoader({
    stereoDrumLoop: "sounds/drums.mp3"



});


$(function() {


    $(document).on("click", function() {

        sound.stereoDrumLoop.connect(nodeGraph).play();


    });


});