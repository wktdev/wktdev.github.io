"use strict";

window.onload = function() {


    var sound = audioBatchLoader({
        drumLoops: "sounds/drums.mp3",


    });





function nodeRight(sound){
         let splitter = audioContext.createChannelSplitter();
        sound.connect(splitter);
        splitter.connect(audioContext.destination, 0); // left output

}


function nodeLeft(sound){
             let splitter = audioContext.createChannelSplitter();
        sound.connect(splitter);
        splitter.connect(audioContext.destination, 1); // left output


}




    var rightChan = document.getElementById("right-chan");

    rightChan.addEventListener("click", function() {

        sound.drumLoops.connect(nodeRight).play();

    });







    var leftChan = document.getElementById("left-chan");

    leftChan.addEventListener("click", function() {

        sound.drumLoops.connect(nodeLeft).play();

    });


};