

let sound = audioBatchLoader({
    stereoDrumLoop: "sounds/drums.mp3",
    sixChannelFile: "sounds/6_channel_file.wav"


});






function nodeGraph(sound){
    let merger = audioContext.createChannelMerger(1); // Set number of channels 
    sound.connect(merger);
    merger.connect(audioContext.destination);
}






$(function() {

    $("#stereo").on("click", function() {

        sound.stereoDrumLoop.connect(nodeGraph).play();
    });

    $("#6-channel-file").on("click", function() {

        sound.sixChannelFile.connect(nodeGraph).play();
    });




});