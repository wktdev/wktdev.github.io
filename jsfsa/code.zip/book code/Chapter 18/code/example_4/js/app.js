"use strict";


function nodeGraph(sound){
     let merger = audioContext.createChannelMerger();
            sound.connect(merger, 0, 1); //outputs inputSource to right channel
            merger.connect(audioContext.destination);
}

    let sound = audioBatchLoader({
        drumLoops: "sounds/drums.mp3",


    });


    window.document.addEventListener("click", function() {

        sound.drumLoops.connect(nodeGraph).play();

    });

