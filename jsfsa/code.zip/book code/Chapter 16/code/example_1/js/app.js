"use strict";

$(function() {

    let sound = audioBatchLoader({
        song: "sounds/song.mp3"


    });

    let playing = false;

    let sliderParams64Hz = {
        'orientation': "vertical",
        'range': "min",
        'min': -30,
        'max': 30,
        'animate': true,
        'step': 0.01,
        'slide': function(event, ui) {
            filter1.gain.value = ui.value;

        }
    };

    $('#filter64Hz').slider(sliderParams64Hz);

    let sliderParams150Hz = {
        'orientation': "vertical",
        'range': "min",
        'min': -30,
        'max': 30,
        'animate': true,
        'step': 0.01,
        'slide': function(event, ui) {
            filter2.gain.value = ui.value;

        }
    };

    $('#filter150Hz').slider(sliderParams150Hz);







    let sliderParams350Hz = {
        'orientation': "vertical",
        'range': "min",
        'min': -30,
        'max': 30,
        'animate': true,
        'step': 0.01,
        'slide': function(event, ui) {
            filter3.gain.value = ui.value;

        }
    };

    $('#filter350Hz').slider(sliderParams350Hz);



    let sliderParams1000Hz = {
        'orientation': "vertical",
        'range': "min",
        'min': -30,
        'max': 30,
        'animate': true,
        'step': 0.01,
        'slide': function(event, ui) {
            filter4.gain.value = ui.value;

        }
    };

    $('#filter1000Hz').slider(sliderParams1000Hz);




    let sliderParams2000Hz = {
        'orientation': "vertical",
        'range': "min",
        'min': -30,
        'max': 30,
        'animate': true,
        'step': 0.01,
        'slide': function(event, ui) {
            filter5.gain.value = ui.value;

        }
    };

    $('#filter2000Hz').slider(sliderParams2000Hz);


    let sliderParams6000Hz = {
        'orientation': "vertical",
        'range': "min",
        'min': -30,
        'max': 30,
        'animate': true,
        'step': 0.01,
        'slide': function(event, ui) {
            filter6.gain.value = ui.value;

        }
    };

    $('#filter6000Hz').slider(sliderParams6000Hz);


    let sliderParams12000Hz = {
        'orientation': "vertical",
        'range': "min",
        'min': -30,
        'max': 30,
        'animate': true,
        'step': 0.01,
        'slide': function(event, ui) {
            filter7.gain.value = ui.value;

        }
    };

    $('#filter12000Hz').slider(sliderParams12000Hz);



    $(".transport-icon").on("click", function() {

        if (!playing) {
            playing = true;
            sound.song.connect(multibandEQ).play();
            $(".transport-icon").attr("src", "images/stop.png");

        } else {
            playing = false;
            sound.song.stop();
            $(".transport-icon").attr("src", "images/play.png");
        }

    });

});