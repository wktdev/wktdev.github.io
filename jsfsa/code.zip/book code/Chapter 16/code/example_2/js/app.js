"use strict";

let sound = audioBatchLoader({
    song: "sounds/song.mp3"


});


$(function() {
    let playing = false;
    $(".transport-icon").on("click", function() {

        if (!playing) {
            playing = true;
            sound.song.connect(parametricEQ).play();
            $(".transport-icon").attr("src", "images/stop.png");

        } else {
            playing = false;
            sound.song.stop();
            $(".transport-icon").attr("src", "images/play.png");
        }

    });

});


$(function() {
    $(".freqDial").knob({

        change: function(valueFreqDial) {
            parametricEQ1.frequency.value = valueFreqDial;


        }
    });

    $(".bandwidthDial").knob({

        change: function(valueBandwidthDial) {
            parametricEQ1.Q.value = valueBandwidthDial;

        }
    });

    $(".gainDial").knob({

        change: function(valueGainDial) {
            parametricEQ1.gain.value = valueGainDial;


        }
    });


});

