"use strict";

console.log(200 == 200); // true
console.log("200hz" == "200hz");; // true



let osc1 = "200hz";
let osc2 = "200hz";
console.log(osc1 == osc2); // true


console.log(200 == "oscillator"); // false