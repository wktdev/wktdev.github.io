"use strict";

//___________________________Not equal operator

console.log(300 != 200); // true
console.log(300 != 300); // false


console.log("300" != 300); // false


//___________________________Not double equal operator

console.log("300" !== 300); // true
console.log(300 !== 300); // false