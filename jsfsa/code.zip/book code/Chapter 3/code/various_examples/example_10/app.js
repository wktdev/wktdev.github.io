"use strict";

console.log(300 <= 300); // true
console.log(300 <= 500); // true
console.log(300 <= 200); // false


console.log(300 <= "300"); // true
console.log(300 <= "500"); // true
console.log(300 <= "200"); // false