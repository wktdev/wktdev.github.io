"use strict";

let osc1 = 300;
let osc2 = 500;
let osc3 = 300;
console.log(osc3 >= osc1); // true
console.log(osc2 >= osc1); // true
console.log(osc1 >= osc2); // false

console.log(300 >= "300"); // true