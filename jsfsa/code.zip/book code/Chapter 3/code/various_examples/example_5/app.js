"use strict";

let oscillatorIsOn = true; // true
oscillatorIsOn = false; // changed to false