"use strict";

//_________________________Examples
900 === 900 // true
let osc1 = 200;
let osc2 = "200";
console.log(osc1 === osc2); // false