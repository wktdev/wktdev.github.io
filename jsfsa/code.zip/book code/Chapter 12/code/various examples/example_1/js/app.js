"use strict";
function makeObj() {
    let obj = {};
    return obj;
}
let newObj = makeObj();