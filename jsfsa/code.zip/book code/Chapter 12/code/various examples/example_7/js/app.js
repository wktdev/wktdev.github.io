"use strict";
function makeRecord(id) {
    let id = id;
    let record = {};
    record.getId = function() { // getter
        return id;
    };
    return record;
}

let myRecord = makeRecord("1121210937");

myRecord.getId(); // 1121210937