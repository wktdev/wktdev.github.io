"use strict";

function makeRecord(id) {
    let id = id; // Private data
    console.log(id + " is private data");
    let record = {};
    return record;
}
let myRecord = makeRecord("2323415432");
console.log(myRecord.id); // undefined. This is a property of the object, not the private data!