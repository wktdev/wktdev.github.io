"use strict";

let myFavoriteSynthCompany = "My favorite synth company is Moog. Moog is great!";
let myNewFavoriteSynthCompany = myFavoriteSynthCompany.replace("Moog", "Dave Smith Instruments");
console.log(myNewFavoriteSynthCompany); // My favorite synth company is Dave Smith Instruments. Moog is great!


/*


var myFavoriteSynthCompany = "My favorite synth company is Moog. Moog is great!";
var myNewFavoriteSynthCompany = myFavoriteSynthCompany.replace(/Moog/gi,"Dave Smith Instruments");
console.log(myNewFavoriteSynthCompany); // My favorite synth company is Dave Smith Instruments. Dave Smith Instruments is great!



*/