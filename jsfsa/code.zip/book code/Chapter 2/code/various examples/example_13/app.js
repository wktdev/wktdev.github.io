"use strict";

Math.round(1000.789) // outputs 1001


Math.min(5000, 2000, 80); // 80
Math.max(5000, 2000, 80); // 5000

//___________________________With variables
let freq_1 = 5000;
let freq_2 = 2000;
let freq_3 = 80;
Math.min(freq_1, freq_2, freq_3); // 80
Math.max(freq_1, freq_2, freq_3); // 5000


//__________________________ceil and floor

Math.ceil(3.00333); // 4
Math.floor(3.9999); // 3





//__________________________random


let randomNumber = Math.random();
console.log(randomNumber); // example: 0.019790495047345757

let max = 20000;
let min = 20;
let randomInteger = Math.floor(Math.random() * (max - min + 1) + min);
console.log(randomInteger); // Between 20 and 20000



//_________________________Absolute value

let num = Math.abs(-100);
console.log(num); // 100


let a = 1000;
let b = 5000;
console.log(Math.abs(b - a)); // 4000