"use strict";

let sound = "oscillator-1";
let oscNumber = sound.charAt(sound.length - 1);
console.log(oscNumber); // 1