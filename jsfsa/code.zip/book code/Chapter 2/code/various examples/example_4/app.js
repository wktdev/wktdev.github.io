"use strict";


let phrase = "This sound is an ";
let soundType = "oscillator";
let sentence = phrase + soundType;
console.log(sentence); //  "This sound is an oscillator".