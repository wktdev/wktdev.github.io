"use strict";


const audioContext = new AudioContext();
//___ 4 variables that represent oscillator waveforms
let saw = "sawtooth";
let sine = "sine";
let tri = "triangle";
let square = "square";
//___ A variable intended to contain one of these waveforms
let currentWaveform = undefined;
currentWaveform = square;
//_____________________________Start of oscillator
let osc = audioContext.createOscillator();
osc.type = currentWaveform; // Assigned it to our oscillator type
osc.connect(audioContext.destination);
osc.start(audioContext.currentTime);