"use strict";

//_______________________________Convert numeric string to number

let numericString = "120";
let num = +numericString; // plus symbol
console.log(num); // 120
console.log(typeof num); // number


//______________________________Convert number to string

let num = 80;
let numericString = num + "";
console.log(numericString); // 80
console.log(typeof numericString); // string





//______________________________________NaN

let osc1 = undefined;
let osc2 = 200;
console.log(osc1 + osc2); // NaN