"use strict";

let synthFrequencies = [5000, 1000, 500];
synthFrequencies.unshift(7500, 6000);
console.log(synthFrequencies); // [ 7500, 6000, 5000, 1000, 500 ];