"use strict";

let sound = "oscillator";
console.log(sound.charAt(1)); //  "s"