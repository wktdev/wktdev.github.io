"use strict";

let oscillator = "sawtooth";
oscillator.toUpperCase(); // SAWTOOTH

/*

var oscillator = "SAWTOOTH";
oscillator.toLowerCase(); // "sawtooth"

*/


console.log(oscillator);