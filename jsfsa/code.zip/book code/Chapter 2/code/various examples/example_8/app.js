"use strict";

let instrument = "piano";
console.log(instrument.length); // 5