"use strict";


let drumMachines = ["MPC", "Maschine", "TR 808"];
let keyboards = ["Juno", "ARP", "Jupiter"];
let percussion = ["vibraphone", "bongos"];
let stringed = ["guitar", "bass", "harp"]
let instruments = drumMachines.concat(keyboards, percussion, stringed);

console.log(instruments); /* [ 'MPC','Maschine','TR 808','Juno','ARP','Jupiter','vibraphone', 'bongos','guitar','bass','harp' ]  */