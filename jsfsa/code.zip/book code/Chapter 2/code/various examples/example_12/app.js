"use strict";

console.log(5 + 5); // 10
console.log(10 - 5); // 5
console.log(5 * 5); // 25
console.log(25 / 5); // 5
console.log(10 % 9); // 1


let oscillator1 = 1000;
let oscillator2 = 100;
let oscillator3 = 20;
let combinedOscillator = oscillator1 + (oscillator2 * oscillator3);
console.log(combinedOscillator); // 3000