let drumMachines = ["MPC", "Maschine", "TR 808"]; 

let instruments = [...drumMachines, 

"Juno", "ARP", "Jupiter", 

"vibraphone", "bongos", 

"guitar", "bass", "harp" 

] 

 
 
 

console.log(instruments) /* [ 'MPC','Maschine','TR 808','Juno','ARP','Jupiter','vibraphone', 'bongos','guitar','bass','harp' ] */ 