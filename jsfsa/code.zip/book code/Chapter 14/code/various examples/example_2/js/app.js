"use strict";

const audioContext = new AudioContext();

let osc = audioContext.createOscillator();
osc.start(audioContext.currentTime);
let filter = audioContext.createBiquadFilter();
filter.type = "lowpass";
osc.connect(filter);
filter.connect(audioContext.destination);