"use strict";  

 

 

$(function() {  

 

 

  let futureTickTime,  

    counter = 1,  

    metronome,  

    metronomeVolume = 1,   

    tempo = 90,  

    secondsPerBeat = 60 / tempo,  

    counterTimeValue = (secondsPerBeat / 4),  

    oscFrequency = 100,  

    timerID,   

    isPlaying = false,   

    osc;  

 

 

 

 

  /*_____________________________________________BEGIN load sounds*/  

 

 

   

 

 

  let sounds = audioBatchLoader({  

    kick: "sounds/kick.mp3",  

    snare: "sounds/snare.mp3",  

    hihat: "sounds/hihat.mp3",  

    shaker: "sounds/shaker.mp3"  

 

 

  });  

 

 

   

 

 

  //_____________________________________________END load sounds */  

 

 

  //_____________________________________________BEGIN Array Tracks    

 

 

 let kickTrack = [ ], 
 snareTrack = [ ], 
 hiHatTrack = [ ], 
 shakerTrack = [ ];

 

  //_____________________________________________END Array Tracks  

 

 

   

 

 

  function scheduleSound(trackArray, sound, count, time) {   

    for (let i = 0; i < trackArray.length; i += 1) {  

      if (count === trackArray[i]) {  

        sound.play(time);  

      }  

    }  

  }  

 

 

   

 

 

  function playMetronome(time, playing, volume) {  

 

 

    if (playing) {  

      osc = audioContext.createOscillator();  

      osc.connect(metronome);  

      metronome.gain.value = volume;  

      metronome.connect(audioContext.destination);  

 

 

      if (counter === 1) {  

        osc.frequency.value = 500;  

 

 

      } else {  

        osc.frequency.value = 300;  

 

 

      }  

 

 

      osc.connect(metronome);  

      metronome.connect(audioContext.destination);  

      osc.start(time);  

      osc.stop(time + 0.1);  

 

 

    }  

 

 

  }  

 

 

  

  function playTick() {  

    console.log("This is 16th note:" + counter);  
    secondsPerBeat = 60 / tempo; 
    counterTimeValue = (secondsPerBeat / 4);

    counter += 1;  

    futureTickTime += counterTimeValue;  

    if (counter > 16) {  

      counter = 1;  

    }  

 

 

  }  

 

 

 

 

  function scheduler() {  

 

 

    if (futureTickTime < audioContext.currentTime + 0.1) {  

      playMetronome(futureTickTime, true, metronomeVolume);  

      scheduleSound(kickTrack, sounds.kick, counter, futureTickTime - audioContext.currentTime);  

      scheduleSound(snareTrack, sounds.snare, counter, futureTickTime - audioContext.currentTime);  

      scheduleSound(hiHatTrack, sounds.hihat, counter, futureTickTime - audioContext.currentTime);  

      scheduleSound(shakerTrack, sounds.shaker, counter, futureTickTime - audioContext.currentTime);  

      playTick();  

 

 

    }  

 

 

    timerID = window.setTimeout(scheduler, 0);   

 

 

  }  

 

 

  function play() {  

    osc = audioContext.createOscillator();  

    metronome = audioContext.createGain();  

    isPlaying = !isPlaying;  

    if (isPlaying) {  

      counter = 1;  

      futureTickTime = audioContext.currentTime;  

      scheduler();  

    } else {  

      window.clearTimeout(timerID);  

    }  

  }  

  $(".play-stop-button").on("click", function() {  

 

 

    play();  

 

 

  });  

      //_____________________________________BEGIN metronome toggle  

  $(".metronome").on("click",function(){  

    if(metronomeVolume){ 

           metronomeVolume = 0; 

        }else{ 

           metronomeVolume = 1; 

        }     

   });  

    //__________________________________END metronome toggle 

    $("#tempo").on("change", function() { 
  tempo = $(this).val();  

   $("#showTempo").html(tempo); 
});

 
    //__________________________________BEGIN create grid  

  for(let i=1;i<=4;i+=1){  

    $(".app-grid").append("<div class='track-"+i+"-container' </div>");  

    for(let j=1;j<17;j+=1){  

    $(".track-"+i+"-container").append("<div class='grid-item track-step step-"+j+"'</div>");  

    }  

    }  

    //__________________________________END create grid  

    //______________________BEGIN Grid interactivity 
function sequenceGridToggler(domEle,arr){ 
$(domEle).on("mousedown",".grid-item",function(){ 
var gridIndexValue=$(this).index();/*__________Get index 
of grid-item*/ 
var offset=gridIndexValue+1;/*_______________Add+1so 
value starts at1instead of0*/ 
var index=arr.indexOf(offset);/*_______________Check if 
value exists in array*/ 
if(index>-1){/*______________________________If index of 
item exist.....*/ 
arr.splice(index,1);//_____________________then remove it.... 
$(this).css("backgroundColor","");/*________and change 
color of DOM element to default*/ 
}else{/*_______________________________________If item does 
not exist.....*/ 
arr.push(offset);/*__________________________then push it to 
track array*/ 
$(this).css("background-color","purple");/*_and change 
color of DOM element to purple.*/ 
} 
}); 
} 
sequenceGridToggler(".track-1-container",kickTrack); 
sequenceGridToggler(".track-2-container",snareTrack); 
sequenceGridToggler(".track-3-container",hiHatTrack); 
sequenceGridToggler(".track-4-container",shakerTrack); 
//______________________END Grid interactivity 

 

}); 