"use strict";

let loopStartVal = 0;
let loopEndVal = 0;

let appSounds = {
    loop: "sounds/drums.mp3", // ________________________________Audio file directory
    count: "sounds/count.mp3", // ___________________________________Audio file directory


};

function nodeGraph(sound){
      sound.loop = true;
        sound.loopStart = loopStartVal;
        sound.loopEnd = loopEndVal;
        sound.connect(audioContext.destination);

}


let sounds = audioBatchLoader(appSounds);
let startTimeVal = 0;
let startPointVal = 0;
let endPointVal = 0;
let soundFileLength = undefined;
let soundFileLengthFloor = undefined;
let playing = false;


setTimeout(function(){
    console.log(appSounds.count.soundToPlay.duration)
},1000);

$(function() {



    $(".transport-icon").on("click", function() {
        console.log("start time:" + startTimeVal);
        console.log("start point:" + startPointVal);
        console.log("end point:" + endPointVal);


        if (!playing) {
            playing = true;
            sounds.count.connect(nodeGraph).play(startTimeVal, startPointVal, endPointVal);
            $(".transport-icon").attr("src", "images/stop.png");
            $(".length-data").empty();
            $(".length-data").append("<b>" + soundFileLength + "</b>");

        } else {
            playing = false;
            sounds.count.stop();
            $(".transport-icon").attr("src", "images/play.png");
        }
        let soundFileLengthFixed = appSounds.count.soundToPlay.duration;

        $('#start-time-slider').slider("option", "max", soundFileLengthFixed);
        $('#start-point-slider').slider("option", "max", soundFileLengthFixed);
        $('#end-point-slider').slider("option", "max", soundFileLengthFixed);

    });








    let startTime = {
        'orientation': "vertical",
        'range': "min",
        'min': 0,
        'max': 0,
        'animate': true,
        'step': 0.01,
        'slide': function(event, ui) {
            startTimeVal = ui.value;


            $("#start-time-val").empty();
            $("#start-time-val").append(ui.value);

            playing = true;
            $(".transport-icon").attr("src", "images/stop.png");
            $(".length-data").empty();
            $(".length-data").append("<b>" + soundFileLength + "</b>");
            sounds.count.stop();
            sounds.count.connect(nodeGraph).play(startTimeVal, startPointVal, endPointVal);


        }
    };

    $('#start-time-slider').slider(startTime, soundFileLength);





    let startPoint = {
        'orientation': "vertical",
        'range': "min",
        'min': 0,
        'max': 0,
        'animate': true,
        'step': 0.01,
        'slide': function(event, ui) {
            startPointVal = ui.value;


            $("#start-point-val").empty();
            $("#start-point-val").append(ui.value);


            playing = true;
            $(".transport-icon").attr("src", "images/stop.png");
            $(".length-data").empty();
            $(".length-data").append("<b>" + soundFileLength + "</b>");

            loopStartVal = +ui.value;

            sounds.count.stop();
            sounds.count.connect(nodeGraph).play(startTimeVal, startPointVal, endPointVal);

        }


    };

    $('#start-point-slider').slider(startPoint);





    let endPoint = {

        'orientation': "vertical",
        'range': "min",
        'min': 0,
        'max': 0,
        'animate': true,
        'step': 0.01,
        'slide': function(event, ui) {
            endPointVal = ui.value;


            $("#end-point-val").empty();
            $("#end-point-val").append(ui.value);

            playing = true;
            $(".transport-icon").attr("src", "images/stop.png");
            $(".length-data").empty();
            $(".length-data").append("<b>" + soundFileLength + "</b>");
            loopEndVal = +ui.value;
            sounds.count.stop();
            sounds.count.connect(nodeGraph).play(startTimeVal, startPointVal, endPointVal);


        }
    };

    $('#end-point-slider').slider(endPoint);



});