"use strict";

let sound = audioBatchLoader({

    test: "sounds/kick.mp3"

});

// window.onload = function() {

//     sound.test.play();
// }
window.addEventListener("mousedown", function() {

    sound.test.play(0,0.2)

});


window.addEventListener("mouseup", function() {

    sound.test.stop()

});