"use strict";
function makeObj() {
    var obj = {};
    return obj;
}
var newObj = makeObj();