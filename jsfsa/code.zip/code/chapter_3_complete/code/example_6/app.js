"use strict";

console.log(200 == 200); // true
console.log("200hz" == "200hz");; // true



var osc1 = "200hz";
var osc2 = "200hz";
console.log(osc1 == osc2); // true


console.log(200 == "oscillator"); // false