"use strict";

var osc1 = 300;
var osc2 = 500;
var osc3 = 300;
console.log(osc3 >= osc1); // true
console.log(osc2 >= osc1); // true
console.log(osc1 >= osc2); // false

console.log(300 >= "300"); // true