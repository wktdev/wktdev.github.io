"use strict";

//_______________________Assignment
var osc1 = 100;
var osc2 = osc1;
console.log(osc2); // 100


/*_______________________Addition assignment
var osc = 100;
osc += 100;
console.log(osc); // 200
*/