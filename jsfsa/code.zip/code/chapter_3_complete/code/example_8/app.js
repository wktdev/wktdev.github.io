"use strict";

console.log(100 < 200); // true
console.log(300 < 200); // false
console.log(300 > 200); // true
console.log(300 > 500); // false




console.log(600 > "500"); // true

console.log(600 < "500");