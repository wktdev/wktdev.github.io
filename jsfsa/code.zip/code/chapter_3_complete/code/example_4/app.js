"use strict";

//___________________Subtraction assignment
var osc = 500;
osc -= 100;
console.log(osc); // 400


/*___________________Multiplication assignment

var osc = 200;
osc *= 2;
osc *= 2;
console.log(osc); // 800


*/

/*___________________Divide assignment 

var osc = 200;
osc /= 2;
osc /= 2;
console.log(osc); // 50


*/

/*___________________Modulo assignment

var osc = 200;
osc %= 150;
console.log(osc); // 50


*/