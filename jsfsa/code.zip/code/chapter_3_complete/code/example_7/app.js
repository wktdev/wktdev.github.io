"use strict";

//_________________________Examples
900 === 900 // true
var osc1 = 200;
var osc2 = "200";
console.log(osc1 === osc2); // false