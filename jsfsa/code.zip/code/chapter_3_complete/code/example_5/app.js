"use strict";

var oscillatorIsOn = true; // true
oscillatorIsOn = false; // changed to false