"use strict";




multFreq(200, 2); // ___ error! "multFreq is not a function"
var multFreq = function(input, val) {
    return input * val;
};