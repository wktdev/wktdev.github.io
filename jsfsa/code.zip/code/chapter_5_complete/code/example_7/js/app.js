"use strict";





function playOsc(oscType, freq) {
    console.log(arguments[0]);
    console.log(arguments[1]);
}
playOsc("sine", 200); // sine 200