"use strict";

function effectsBox(input) {

    return input * 2;

}

console.log(effectsBox(120)); // Output 240