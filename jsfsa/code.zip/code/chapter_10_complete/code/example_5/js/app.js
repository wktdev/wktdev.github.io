$(function() {
    $("input").on("click", function() { //click event listener
        alert("You clicked play");
    });
});