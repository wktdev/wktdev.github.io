$(function() {
    $("div").css("background-color", "orange");

    //_______________________________BEGIN css example with multi selector with object

    $("div").css({
        backgroundColor: "orange",
        width: "100px",
        borderStyle: "solid"
    });


    //__________________________________END css example with multi selector with object */
});