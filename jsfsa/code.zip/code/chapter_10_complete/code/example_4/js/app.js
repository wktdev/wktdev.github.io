$(function() {
    $("div").css({
        backgroundColor: "orange",
        width: "100px",
        borderStyle: "solid"
    }).fadeIn(1000).fadeOut(1000); // example of method chaining
});