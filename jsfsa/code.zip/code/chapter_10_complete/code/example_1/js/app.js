$(function() {
    //   code goes here
})