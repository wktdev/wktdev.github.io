$(function() {
    var $transportControl = $("div");
});