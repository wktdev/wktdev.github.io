"use strict";

function logger(data) {
    console.log(data);
}