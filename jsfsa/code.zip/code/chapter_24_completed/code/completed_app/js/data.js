{
    "buzzFunk": [{
        "type": "sawtooth",
        "frequency": 65.25,
        "volume": 1
    }, {
        "type": "triangle",
        "frequency": 65.25,
        "volume": 1
    }, {

        "type": "sawtooth",
        "frequency": 67.25,
        "volume": 0.3
    }],
    "gameSound": [{
        "type": "square",
        "frequency": 100.25,
        "volume": 1

    }, {
        "type": "triangle",
        "frequency": 65.25,
        "volume": 1
    }, {

        "type": "sawtooth",
        "frequency": 67.25,
        "volume": 0.3
    }]
}