"use strict";


var freq = 7000;

while (freq > 0) {
    console.log(freq);
    freq -= 100;
}