"use strict";

for (var i = 0; i <= 16; i += 1) {
    console.log(i);
}