"use strict";

//________________________Pop

var synthFrequencies = [5000, 1000, 500];
synthFrequencies.pop();
console.log(synthFrequencies); // [ 5000, 1000]



/*________________________Pop and capture data

var synthFrequencies = [5000, 1000, 500];
var lastItem = synthFrequencies.pop();
console.log(lastItem);  // 500

*/