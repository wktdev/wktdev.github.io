"use strict";


var waveforms = ["square", "sawtooth", "triangle", "sine"]; // array with some data

waveforms[0]; // square
waveforms[1]; // sawtooth
waveforms[2]; // triangle
waveforms[3]; // sine
waveforms[4]; // undefined ( no data )