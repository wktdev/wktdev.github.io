"use strict";

var instrument = "piano";
console.log(instrument.length); // 5