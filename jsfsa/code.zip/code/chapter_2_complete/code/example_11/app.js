"use strict";

var waveform = "sine";
var polyphony = 16;
console.log(typeof waveform); //  string
console.log(typeof polyphony); // number