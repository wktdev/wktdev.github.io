"use strict";

var sound = "oscillator";
console.log(sound.charAt(1)); //  "s"