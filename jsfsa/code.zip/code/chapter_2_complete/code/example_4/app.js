"use strict";


var phrase = "This sound is an ";
var soundType = "oscillator";
var sentence = phrase + soundType;
console.log(sentence); //  "This sound is an oscillator".