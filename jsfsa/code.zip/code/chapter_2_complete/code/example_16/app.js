"use strict";

//__________________________PUSH

var synthFrequencies = [5000, 1000, 500];
synthFrequencies.push(100); // This places a new item at the end of the array
console.log(synthFrequencies); // [5000,1000,500,100]

/*_________________________PUSH multiple items

var synthFrequencies = [5000, 1000, 500];
synthFrequencies.push(100, 50, 30); 
console.log(synthFrequencies); // [ 5000, 1000, 500, 100, 50, 30]

*/