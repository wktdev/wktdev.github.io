"use strict";

var sound = "oscillator-1";
var oscNumber = sound.charAt(sound.length - 1);
console.log(oscNumber); // 1