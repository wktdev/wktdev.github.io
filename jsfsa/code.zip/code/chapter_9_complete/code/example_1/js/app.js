"use strict";


window.onload = function() {
    var playButton = document.getElementById("play-button");
    playButton.addEventListener("click", function() {
        alert("You clicked the play button");
    });
};