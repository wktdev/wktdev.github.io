"use strict";

$(function() {


    $(document).on("click", function() {

        sound.stereoDrumLoop.play();


    });


});